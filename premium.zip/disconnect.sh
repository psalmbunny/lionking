#!/bin/bash

HOST='212.237.53.120'
USER='super'
PASS='Qwerty1234'
DB='super_db'
PORT='3306'

mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "UPDATE users SET is_active=1 WHERE user_name='$common_name' "